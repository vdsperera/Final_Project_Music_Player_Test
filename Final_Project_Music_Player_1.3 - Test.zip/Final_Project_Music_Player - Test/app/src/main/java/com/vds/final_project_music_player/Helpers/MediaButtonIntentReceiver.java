package com.vds.final_project_music_player.Helpers;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;
import android.view.KeyEvent;

import com.vds.final_project_music_player.Activities.MainActivity;
import com.vds.final_project_music_player.MusicService;
import com.vds.final_project_music_player.Utils.PreferencesUtility;

/**
 * Created by Vidumini on 2/24/2018.
 */

public class MediaButtonIntentReceiver {

}
