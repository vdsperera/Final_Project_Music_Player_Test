package com.vds.final_project_music_player;

import android.app.Service;
import android.content.ContentUris;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.util.Log;

import com.vds.final_project_music_player.Adapters.SongAdapter;
import com.vds.final_project_music_player.DataLoaders.SongLoader;
import com.vds.final_project_music_player.Models.SongInfo;

import java.util.ArrayList;

/**
 * Created by Vidumini on 2/23/2018.
 */

public class MusicService extends Service implements MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener, MediaPlayer.OnCompletionListener{
    private MediaPlayer mediaPlayer;
    private ArrayList<SongInfo> songs;
    private int songPos;
    private final IBinder mBinder = new MusicBinder();
    SongAdapter adapter;

    public class MusicBinder extends Binder {

        public MusicService getService(){
            Log.d("muAp","Service getService()");
            return MusicService.this;
        }
    }

    @Override
    public void onCreate() {
        Log.d("muAp","Service OnCreate");
        super.onCreate();
        songPos = 0;
        mediaPlayer = new MediaPlayer();
        initMediaPlayer();
    }


    public void initMediaPlayer(){
        Log.d("muAp","Service initMediaPlayer()");
        mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mediaPlayer.setOnPreparedListener(this);
        mediaPlayer.setOnErrorListener(this);
        mediaPlayer.setOnCompletionListener(this);
    }

    public void playSong(){
        Log.d("muAp","Service playSong()");
        mediaPlayer.reset();

        SongInfo playSong = songs.get(songPos);
        long currSong = playSong.getId();
        Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,currSong);
        try {
            mediaPlayer.setDataSource(getApplicationContext(),uri);
            initMediaPlayer();
            mediaPlayer.prepareAsync();
        }catch (Exception ee){
            Log.d("muAp","errrrrrrrr");
        }


    }

    public void setSoong(int songIndex){
        Log.d("muAp","Service setSong()");
        songPos = songIndex;
    }

    public void setList(ArrayList<SongInfo> songInfos){
        Log.d("muAp","Service setList()");
        songs = songInfos;
    }


    @Override
    public IBinder onBind(Intent intent) {
        Log.d("muAp","Service onBind()");
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("muAp","Service onUnbind()");
        mediaPlayer.stop();
        mediaPlayer.release();
        return false;
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        Log.d("muAp","Service onCompletion()");
    }

    @Override
    public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {
        Log.d("muAp","Service onError()");
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        Log.d("muAp","Service onPrepared()");
        mediaPlayer.start();
    }
}
