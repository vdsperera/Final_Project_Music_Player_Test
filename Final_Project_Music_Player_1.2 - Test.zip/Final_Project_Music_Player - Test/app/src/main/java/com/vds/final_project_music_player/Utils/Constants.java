package com.vds.final_project_music_player.Utils;

/**
 * Created by Vidumini on 2/12/2018.
 */

public class Constants {
    public static final String ALBUM_ID = "album_id";
}
