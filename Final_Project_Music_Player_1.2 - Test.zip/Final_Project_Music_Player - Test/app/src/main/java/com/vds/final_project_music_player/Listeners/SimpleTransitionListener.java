package com.vds.final_project_music_player.Listeners;

import android.support.annotation.NonNull;
import android.support.transition.Transition;

/**
 * Created by Vidumini on 2/14/2018.
 */

public class SimpleTransitionListener implements Transition.TransitionListener{

    @Override
    public void onTransitionStart(@NonNull Transition transition) {

    }

    @Override
    public void onTransitionEnd(@NonNull Transition transition) {

    }

    @Override
    public void onTransitionCancel(@NonNull Transition transition) {

    }

    @Override
    public void onTransitionPause(@NonNull Transition transition) {

    }

    @Override
    public void onTransitionResume(@NonNull Transition transition) {

    }
}
