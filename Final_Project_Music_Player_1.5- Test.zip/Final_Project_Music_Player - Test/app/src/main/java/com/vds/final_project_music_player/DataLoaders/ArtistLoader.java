package com.vds.final_project_music_player.DataLoaders;

/**
 * Created by Vidumini on 1/21/2018.
 */

public class ArtistLoader {
}
