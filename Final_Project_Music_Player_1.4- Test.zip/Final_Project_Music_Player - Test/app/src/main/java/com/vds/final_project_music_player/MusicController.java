package com.vds.final_project_music_player;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.MediaController;

/**
 * Created by Vidumini on 4/1/2018.
 */

public class MusicController extends MediaController {
    public MusicController(Context context) {
        super(context);
    }

    public void hide(){

    }
}
