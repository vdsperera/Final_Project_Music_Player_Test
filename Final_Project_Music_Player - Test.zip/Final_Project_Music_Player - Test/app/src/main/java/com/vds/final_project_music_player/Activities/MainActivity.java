package com.vds.final_project_music_player.Activities;

import android.graphics.Color;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import com.afollestad.appthemeengine.ATEActivity;
import com.afollestad.appthemeengine.Config;
import com.afollestad.appthemeengine.customizers.ATENavigationBarCustomizer;
import com.afollestad.appthemeengine.customizers.ATEToolbarCustomizer;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.vds.final_project_music_player.Fragments.AlbumsFragment;
import com.vds.final_project_music_player.Fragments.ArtistsFragment;
import com.vds.final_project_music_player.Fragments.MainFragment;
import com.vds.final_project_music_player.R;
import com.vds.final_project_music_player.Fragments.SongsFragment;

public class MainActivity extends ATEActivity implements ATEToolbarCustomizer, ATENavigationBarCustomizer {

    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageLoader.getInstance().init(ImageLoaderConfiguration.createDefault(getApplicationContext()));
        //ATE.config(this,null).coloredActionBar(true);

        //viewPager = findViewById(R.id.view_pager);
        //viewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));
        Fragment fragment = new MainFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container,fragment).commitAllowingStateLoss();

    }

    @Override
    public int getLightToolbarMode(@Nullable Toolbar toolbar) {
        return Config.LIGHT_TOOLBAR_AUTO;
    }

    @Override
    public int getToolbarColor(@Nullable Toolbar toolbar) {
        return Color.BLACK;
    }

    @Override
    public int getNavigationBarColor() {
        return Color.BLUE;
    }
}

class MyAdapter extends FragmentPagerAdapter{

    public MyAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        if(position==0){
            fragment = new SongsFragment();
        }
        if(position==1){
            fragment = new AlbumsFragment();
        }
        if(position==2){
            fragment = new ArtistsFragment();
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return 3;
    }
}
