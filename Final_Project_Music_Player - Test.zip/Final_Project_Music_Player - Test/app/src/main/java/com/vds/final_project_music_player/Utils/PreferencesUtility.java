package com.vds.final_project_music_player.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.preference.PreferenceManager;

/**
 * Created by Vidumini on 2/3/2018.
 */

public class PreferencesUtility {
    public static final String ALBUM_SORT_ORDER = "album_sort_order";
    private static final String TOGGLE_ALBUM_GRID = "toggle_album_grid";

    private static PreferencesUtility instance;
    private static SharedPreferences preferences;
    private static Context context;
    private static ConnectivityManager connectivityManager;

    public PreferencesUtility(final Context context){
        this.context = context;
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static final PreferencesUtility getInstance(final Context context){
        if (instance == null){
            instance = new PreferencesUtility(context.getApplicationContext());
        }
        return instance;
    }

    public final String getAlbumSortOrder(){
        return preferences.getString(ALBUM_SORT_ORDER,SortOrder.AlbumSortOrder.ALBUM_A_Z);
    }

    public boolean isAlbumsGrid(){
        return preferences.getBoolean(TOGGLE_ALBUM_GRID,true);
    }

}
