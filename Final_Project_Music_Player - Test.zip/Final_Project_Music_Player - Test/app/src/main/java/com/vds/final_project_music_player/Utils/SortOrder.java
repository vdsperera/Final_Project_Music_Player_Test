package com.vds.final_project_music_player.Utils;

import android.provider.MediaStore;

/**
 * Created by Vidumini on 2/3/2018.
 */

public class SortOrder {

    public interface AlbumSortOrder{
        String ALBUM_A_Z = MediaStore.Audio.Albums.DEFAULT_SORT_ORDER;
    }
}
