package com.vds.final_project_music_player.Fragments;


import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.vds.final_project_music_player.DataLoaders.SongLoader;
import com.vds.final_project_music_player.R;
import com.vds.final_project_music_player.Adapters.SongAdapter;
import com.vds.final_project_music_player.Models.SongInfo;

import java.io.IOException;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class SongsFragment extends Fragment {

    private ArrayList<SongInfo> songInfos = new ArrayList<SongInfo>();
    private RecyclerView recyclerView;
    private SongAdapter songAdapter;
    MediaPlayer mediaPlayer;
    View rootView;
    LinearLayoutManager linearLayoutManager;
    DividerItemDecoration dividerItemDecoration;


    public SongsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_recyclerview,container,false);

        recyclerView = (RecyclerView) rootView.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        songAdapter = new SongAdapter(getContext(),songInfos);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),linearLayoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(songAdapter);

        songAdapter.setOnItemClickListener(new SongAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(final Button b, View v, SongInfo obj, int possition) {
                try {
                    if (b.getText().toString().equals("Stop")) {
                        b.setText("Play");
                        mediaPlayer.stop();
                        mediaPlayer.reset();
                        mediaPlayer.release();
                        mediaPlayer = null;

                    } else {
                        mediaPlayer = new MediaPlayer();
                        mediaPlayer.setDataSource(obj.getSongURL());
                        mediaPlayer.prepareAsync();
                        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                            @Override
                            public void onPrepared(MediaPlayer mediaPlayer) {
                                mediaPlayer.start();
                                b.setText("Stop");
                            }
                        });
                    }
                }
                catch (IOException e){

                }
            }
        });


       // new LoadSongs().execute("");
        return rootView;

    }

    private void checkPermissionnn(){
        Log.d("Music","MSG Check permission start");
        if(Build.VERSION.SDK_INT >= 23) {
            Log.d("Music","MSG Check permission if start");
            if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                Log.d("Music","MSG CheckSelfPermission if");
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 123);
                Log.d("Music","MSG Check permission if");
                return;
            }
            else {
                loadSongs();
            }
        }else {
            loadSongs();
            Log.d("Music","MSG Check permission else");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode){
            case 123:
                if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    loadSongs();
                    Log.d("Music","MSG onrequest permission if");
                }else {
                    Toast.makeText(getContext(),"Permission Denied",Toast.LENGTH_LONG).show();
                    checkPermissionnn();
                    Log.d("Music","MSG onRequest permission else");
                }
                break;

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                Log.d("Music","MSG onRequest permission default");

        }

    }

    public void loadSongs(){

        Log.d("Music","MSG loadSong start");
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor cursor = getContext().getContentResolver().query(uri,null,selection,null,null);

        if(cursor != null){
            if(cursor.moveToFirst()){
                do {
                    String name = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME));
                    String artist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
                    String url = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));

                    SongInfo s = new SongInfo(name,artist,url);
                    songInfos.add(s);
                }while (cursor.moveToNext());
                Log.d("Music","MSG loadSongs if");
            }
            cursor.close();
            songAdapter = new SongAdapter(getContext(),songInfos);
            Log.d("Music","MSG loadSongs end");
        }
    }

    public void onMetaChanged() {
        if (songAdapter != null)
            songAdapter.notifyDataSetChanged();
    }



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermissionnn();
        //new LoadSongs().execute("");
    }

    private class LoadSongs extends AsyncTask<String,Void,String>{
        @Override
        protected String doInBackground(String... strings) {
            if(getActivity() != null)
                songAdapter = new SongAdapter((AppCompatActivity) getActivity(), SongLoader.getAllSongs(getActivity()));
            return "Executed";

        }

        @Override
        protected void onPostExecute(String result) {
            recyclerView.setAdapter(songAdapter);
            if (getActivity() != null)
                recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));

        }
    }
}
